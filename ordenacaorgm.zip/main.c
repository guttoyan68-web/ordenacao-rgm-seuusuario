// Projeto de Ordenação - RGM
// Arquivos combinados em um único código para facilitar a execução
// ---------------------------------------------------------------
// Métodos implementados: Insertion Sort, Merge Sort, Quick Sort
// Coleta de métricas: comparações e trocas/movimentações
// Benchmark com RGM + vetores aleatórios

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// ---------------------------------------------------------------
// Estrutura de métricas
// ---------------------------------------------------------------
typedef struct {
long long cmp;
long long swp;
} Metrics;

void reset(Metrics *m) {
m->cmp = 0;
m->swp = 0;
}

#define COUNT_CMP(m) ((m)->cmp++)
#define COUNT_SWP(m) ((m)->swp++)

// ---------------------------------------------------------------
// Insertion Sort
// ---------------------------------------------------------------
void insertion_sort(int *v, int n, Metrics *m) {
for (int i = 1; i < n; i++) {
int key = v[i];
int j = i - 1;
while (j >= 0) {
COUNT_CMP(m);
if (v[j] > key) {
v[j + 1] = v[j];
COUNT_SWP(m);
j--;
} else break;
}
v[j + 1] = key;
COUNT_SWP(m);
}
}

// ---------------------------------------------------------------
// Merge Sort
// ---------------------------------------------------------------
void merge(int *v, int l, int m, int r, Metrics *met) {
int n1 = m - l + 1;
int n2 = r - m;


int *L = malloc(n1 * sizeof(int));
int *R = malloc(n2 * sizeof(int));

for (int i = 0; i < n1; i++) L[i] = v[l + i];
for (int j = 0; j < n2; j++) R[j] = v[m + 1 + j];

int i = 0, j = 0, k = l;

while (i < n1 && j < n2) {
    COUNT_CMP(met);
    if (L[i] <= R[j]) {
        v[k++] = L[i++];
        COUNT_SWP(met);
    } else {
        v[k++] = R[j++];
        COUNT_SWP(met);
    }
}

while (i < n1) {
    v[k++] = L[i++];
    COUNT_SWP(met);
}

while (j < n2) {
    v[k++] = R[j++];
    COUNT_SWP(met);
}

free(L);
free(R);


}

void merge_sort(int *v, int l, int r, Metrics *m) {
if (l < r) {
int mid = (l + r) / 2;
merge_sort(v, l, mid, m);
merge_sort(v, mid + 1, r, m);
merge(v, l, mid, r, m);
}
}

// ---------------------------------------------------------------
// Quick Sort (Lomuto)
// ---------------------------------------------------------------
int partition(int *v, int l, int r, Metrics *m) {
int pivot = v[r];
int i = l - 1;


for (int j = l; j < r; j++) {
    COUNT_CMP(m);
    if (v[j] <= pivot) {
        i++;
        int tmp = v[i]; v[i] = v[j]; v[j] = tmp;
        COUNT_SWP(m);
    }
}

int tmp = v[i + 1]; v[i + 1] = v[r]; v[r] = tmp;
COUNT_SWP(m);

return i + 1;


}

void quick_sort(int *v, int l, int r, Metrics *m) {
if (l < r) {
int p = partition(v, l, r, m);
quick_sort(v, l, p - 1, m);
quick_sort(v, p + 1, r, m);
}
}

// ---------------------------------------------------------------
// Função para medir tempo
// ---------------------------------------------------------------
double run_sort(void (*fn)(int*,int,Metrics*), int *v, int n, Metrics *m) {
reset(m);
clock_t t0 = clock();
fn(v, n, m);
clock_t t1 = clock();
return 1000.0 * (t1 - t0) / CLOCKS_PER_SEC;
}

// Para Merge e Quick que precisam de limites

double run_sort_range(void (*fn)(int*,int,int,Metrics*), int *v, int n, Metrics *m) {
reset(m);
clock_t t0 = clock();
fn(v, 0, n - 1, m);
clock_t t1 = clock();
return 1000.0 * (t1 - t0) / CLOCKS_PER_SEC;
}

// ---------------------------------------------------------------
// Gerar vetor aleatório
// ---------------------------------------------------------------
void gerar_vetor(int *v, int n) {
for (int i = 0; i < n; i++) v[i] = rand() % 10000;
}

// ---------------------------------------------------------------
// MAIN
// ---------------------------------------------------------------
int main() {
char rgm[50];
printf("Digite seu RGM: ");
scanf("%s", rgm);


int n_rgm = strlen(rgm);
int *vrgm = malloc(n_rgm * sizeof(int));

for (int i = 0; i < n_rgm; i++) vrgm[i] = rgm[i] - '0';

Metrics m;

printf("metodo,N,caso,comparacoes,trocas,tempo_ms");


// RGM -------------------------------------------------------------------

int *aux = malloc(n_rgm * sizeof(int));

memcpy(aux, vrgm, n_rgm*sizeof(int));
double t = run_sort(insertion_sort, aux, n_rgm, &m);
printf("insertion,%d,rgm,%lld,%lld,%.3f", n_rgm, m.cmp, m.swp, t);


memcpy(aux, vrgm, n_rgm*sizeof(int));
t = run_sort_range(merge_sort, aux, n_rgm, &m);
printf("merge,%d,rgm,%lld,%lld,%.3f", n_rgm, m.cmp, m.swp, t);
memcpy(aux, vrgm, n_rgm*sizeof(int));
t = run_sort_range(quick_sort, aux, n_rgm, &m);
printf("quick,%d,rgm,%lld,%lld,%.3f", n_rgm, m.cmp, m.swp, t);

// Benchmarks -------------------------------------------------------------
int tamanhos[3] = {100, 1000, 10000};

for (int k = 0; k < 3; k++) {
    int N = tamanhos[k];
    int *v = malloc(N * sizeof(int));

    // Insertion ---------------------------------------------------------
    gerar_vetor(v, N);
    memcpy(aux, v, N*sizeof(int));
    t = run_sort(insertion_sort, aux, N, &m);
    printf("insertion,%d,aleatorio,%lld,%lld,%.3f", N, m.cmp, m.swp, t);

    // Merge -------------------------------------------------------------
    gerar_vetor(v, N);
    memcpy(aux, v, N*sizeof(int));
    t = run_sort_range(merge_sort, aux, N, &m);
    printf("merge,%d,aleatorio,%lld,%lld,%.3f", N, m.cmp, m.swp, t);

    // Quick -------------------------------------------------------------
    gerar_vetor(v, N);
    memcpy(aux, v, N*sizeof(int));
    t = run_sort_range(quick_sort, aux, N, &m);
    printf("quick,%d,aleatorio,%lld,%lld,%.3f", N, m.cmp, m.swp, t);

    free(v);
}

free(vrgm);
free(aux);

return 0;


}
